﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using evalute = WindowsFormsApplication_LuckyTicket.lt_Evaluation.Class_Evaluating;
using parse = WindowsFormsApplication_LuckyTicket.lt_Evaluation.Class_Parsing;

namespace WindowsFormsApplication_LuckyTicket.lt_Evaluation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button_CheckVariant_Click(object sender, EventArgs e)
        {
            short[] arr = { -1, -1, -1, -1, -1, -1 };
            short def = -1;

            string str_arr = this.textBox_Input.Text;
            int count = Math.Min(str_arr.Length, 6);
            for (int i = 0; i < count; i++)
            {
                string str = str_arr[i].ToString();
                arr[i] = Class_Parsing.StrToShortDef(str, def);
            }

            short sh_checked = Class_Evaluating.DEF_VARIANT_DEFAULT;
            if (this.radioButton_VariantTask.Checked)
                sh_checked = Class_Evaluating.DEF_VARIANT_TASK;

            short sh_answer = Class_Evaluating.IsHappyLucky(arr, sh_checked);
            string str_answer = Class_Evaluating.GetMessageByLuckyValue(sh_answer);
            MessageBox.Show(str_answer);
        }
        private void button_FindAllLucky_Click(object sender, EventArgs e)
        {
            short sh_checked = Class_Evaluating.DEF_VARIANT_DEFAULT;
            if (this.radioButton_VariantTask.Checked)
                sh_checked = Class_Evaluating.DEF_VARIANT_TASK;

            List<string> lst_lucky = new List<string>();
            short[] sh_arr = { -1, -1, -1, -1, -1, -1 };

            long lg_count_i = 0;
            for (long lg_i = 0; lg_i <= 999999; lg_i += 111111)
            {
                Class_Parsing.ConvertLongToArray(lg_i, ref sh_arr);
                short sh_answer = Class_Evaluating.IsHappyLucky(sh_arr, sh_checked);
                if (sh_answer == Class_Evaluating.DEF_LUCKY_TICKET)
                {
                    string str = "[" + lg_count_i.ToString() + "] " + Class_Parsing.ConvertLongToString(lg_i, 6);
                    lst_lucky.Add(str);
                    lg_count_i++;
                }
            }

            listBox_Enumerate.Items.Clear();
            listBox_Enumerate.Items.AddRange(lst_lucky.ToArray());
        }
    }
}
