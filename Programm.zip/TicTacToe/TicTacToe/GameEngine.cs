﻿using System;
using System.Drawing;

namespace TicTacToe
{
    internal class GameEngine
    {
        internal enum GameMode { None, PlayerVsPlayer, PlayerVsCPU }
        internal enum WhooseTurn { Player1Human, Player2Human, Player2CPU }

        private GameMode Mode { get; set; } = GameMode.None;
        private WhooseTurn Turn { get; set; } = WhooseTurn.Player1Human;
        private string Winner { get; set; } = "";
        private int player1Score = 0;
        private int player2Score = 0;
        private int numberOfDraws = 0;

        const char EMPTY_CELL = '-';
        const char X_MARK = 'X';
        const char O_MARK = 'O';

        public const string PLAYER_HUMAN_TITLE = "Игрок";
        public const string PLAYER_CPU_TITLE = "Компьютер";

        private char[][] gameField = new char[][] {
            new char[] { EMPTY_CELL, EMPTY_CELL, EMPTY_CELL },
            new char[] { EMPTY_CELL, EMPTY_CELL, EMPTY_CELL },
            new char[] { EMPTY_CELL, EMPTY_CELL, EMPTY_CELL }
        };

        public GameMode GetCurrentMode() => Mode;
        public bool IsGameStarted() => Mode != GameMode.None;
        public WhooseTurn GetCurrentTurn() => Turn;
        public string GetWinner() => Winner;
        public bool IsPlayer1HumanTurn() => Turn == WhooseTurn.Player1Human;
        public void SetPlayer1HumanTurn() => Turn = WhooseTurn.Player1Human;
        public void ResetScore() { player1Score = 0; player2Score = 0; numberOfDraws = 0; }
        public void PrepareForNewGame() { Mode = GameMode.None; ResetScore(); }

        public void StartGame(GameMode gameMode)
        {
            if (gameMode == GameMode.None) return;
            ResetScore();
            Mode = gameMode;
            Turn = WhooseTurn.Player1Human;
        }

        public string GetCurrentPlayer1Title()
        {
            return Mode switch
            {
                GameMode.PlayerVsCPU => PLAYER_HUMAN_TITLE,
                GameMode.PlayerVsPlayer => PLAYER_HUMAN_TITLE + " 1",
                _ => ""
            };
        }

        public string GetCurrentPlayer2Title()
        {
            return Mode switch
            {
                GameMode.PlayerVsCPU => PLAYER_CPU_TITLE,
                GameMode.PlayerVsPlayer => PLAYER_HUMAN_TITLE + " 2",
                _ => ""
            };
        }

        public string GetCurrentMarkLabelText() => IsPlayer1HumanTurn() ? X_MARK.ToString() : O_MARK.ToString();
        public Color GetCurrentMarkLabelColor() => IsPlayer1HumanTurn() ? Color.Gold : Color.Fuchsia;
        public int GetPlayer1Score() => player1Score;
        public int GetPlayer2Score() => player2Score;

        public string GetWhooseTurnTitle()
        {
            return Mode switch
            {
                GameMode.PlayerVsCPU => Turn == WhooseTurn.Player1Human ? PLAYER_HUMAN_TITLE : PLAYER_CPU_TITLE,
                GameMode.PlayerVsPlayer => Turn == WhooseTurn.Player1Human ? PLAYER_HUMAN_TITLE + " 1" : PLAYER_HUMAN_TITLE + " 2",
                _ => ""
            };
        }

        public string GetWhooseNextTurnTitle()
        {
            return Mode switch
            {
                GameMode.PlayerVsCPU => Turn == WhooseTurn.Player1Human ? PLAYER_CPU_TITLE : PLAYER_HUMAN_TITLE,
                GameMode.PlayerVsPlayer => Turn == WhooseTurn.Player1Human ? PLAYER_HUMAN_TITLE + " 2" : PLAYER_HUMAN_TITLE + " 1",
                _ => ""
            };
        }

        public void ClearGameField()
        {
            for (int row = 0; row < 3; row++)
                for (int col = 0; col < 3; col++)
                    gameField[row][col] = EMPTY_CELL;
        }

        public void MakeTurnAndFillGameFieldCell(int row, int column)
        {
            if (IsPlayer1HumanTurn())
            {
                gameField[row][column] = X_MARK;
                Turn = Mode == GameMode.PlayerVsCPU ? WhooseTurn.Player2CPU : WhooseTurn.Player2Human;
            }
            else
            {
                gameField[row][column] = O_MARK;
                Turn = WhooseTurn.Player1Human;
            }
        }

        public bool IsAnyFreeCell()
        {
            for (int row = 0; row < 3; row++)
                for (int col = 0; col < 3; col++)
                    if (gameField[row][col] == EMPTY_CELL) return true;
            return false;
        }

        public Cell MakeComputerTurnAndGetCell()
        {
            Cell attackedCell = ComputerTryAttackCell();
            if (!attackedCell.IsErrorCell()) return attackedCell;

            Cell defendedCell = ComputerTryDefendCell();
            if (!defendedCell.IsErrorCell()) return defendedCell;

            if (IsAnyFreeCell())
                return ComputerTrySelectRandomFreeCell();

            return Cell.ErrorCell();
        }

        private Cell ComputerTryAttackCell()
        {
            Cell cell;
            cell = ComputerTryAttackHorizontalCell(); if (!cell.IsErrorCell()) return cell;
            cell = ComputerTryAttackVerticalCell(); if (!cell.IsErrorCell()) return cell;
            cell = ComputerTryAttackDiagonalCell(); if (!cell.IsErrorCell()) return cell;
            return Cell.ErrorCell();
        }

        private Cell ComputerTryDefendCell()
        {
            Cell cell;
            cell = ComputerTryDefendHorizontalCell(); if (!cell.IsErrorCell()) return cell;
            cell = ComputerTryDefendVerticalCell(); if (!cell.IsErrorCell()) return cell;
            cell = ComputerTryDefendDiagonalCell(); if (!cell.IsErrorCell()) return cell;
            return Cell.ErrorCell();
        }

        private Cell ComputerTryAttackHorizontalCell() => GetHorizontalCellForAttackOrDefence(O_MARK);
        private Cell ComputerTryAttackVerticalCell() => GetVerticalCellForAttackOrDefence(O_MARK);
        private Cell ComputerTryAttackDiagonalCell() => GetDiagonalCellForAttackOrDefence(O_MARK);
        private Cell ComputerTryDefendHorizontalCell() => GetHorizontalCellForAttackOrDefence(X_MARK);
        private Cell ComputerTryDefendVerticalCell() => GetVerticalCellForAttackOrDefence(X_MARK);
        private Cell ComputerTryDefendDiagonalCell() => GetDiagonalCellForAttackOrDefence(X_MARK);

        private Cell GetHorizontalCellForAttackOrDefence(char checkMark)
        {
            for (int row = 0; row < 3; row++)
            {
                int count = 0;
                int freeCol = -1;
                for (int col = 0; col < 3; col++)
                {
                    if (gameField[row][col] == checkMark) count++;
                    if (gameField[row][col] == EMPTY_CELL) freeCol = col;
                }
                if (count == 2 && freeCol != -1) return Cell.From(row, freeCol);
            }
            return Cell.ErrorCell();
        }

        private Cell GetVerticalCellForAttackOrDefence(char checkMark)
        {
            for (int col = 0; col < 3; col++)
            {
                int count = 0;
                int freeRow = -1;
                for (int row = 0; row < 3; row++)
                {
                    if (gameField[row][col] == checkMark) count++;
                    if (gameField[row][col] == EMPTY_CELL) freeRow = row;
                }
                if (count == 2 && freeRow != -1) return Cell.From(freeRow, col);
            }
            return Cell.ErrorCell();
        }

        private Cell GetDiagonalCellForAttackOrDefence(char checkMark)
        {
            int count1 = 0, count2 = 0;
            int free1Row = -1, free1Col = -1;
            int free2Row = -1, free2Col = -1;

            for (int i = 0; i < 3; i++)
            {
                if (gameField[i][i] == checkMark) count1++;
                if (gameField[i][2 - i] == checkMark) count2++;
                if (gameField[i][i] == EMPTY_CELL) { free1Row = i; free1Col = i; }
                if (gameField[i][2 - i] == EMPTY_CELL) { free2Row = i; free2Col = 2 - i; }
            }

            if (count1 == 2 && free1Row != -1) return Cell.From(free1Row, free1Col);
            if (count2 == 2 && free2Row != -1) return Cell.From(free2Row, free2Col);

            return Cell.ErrorCell();
        }

        private Cell ComputerTrySelectRandomFreeCell()
        {
            Random rnd = new Random();
            int maxAttempts = 1000;
            int row, col;
            for (int i = 0; i < maxAttempts; i++)
            {
                row = rnd.Next(3);
                col = rnd.Next(3);
                if (gameField[row][col] == EMPTY_CELL)
                    return Cell.From(row, col);
            }

            for (row = 0; row < 3; row++)
                for (col = 0; col < 3; col++)
                    if (gameField[row][col] == EMPTY_CELL)
                        return Cell.From(row, col);

            return Cell.ErrorCell();
        }

        public bool IsDraw()
        {
            bool draw = !IsAnyFreeCell();
            if (draw) numberOfDraws++;
            return draw;
        }

        public bool IsWin()
        {
            return CheckWinOnHorizontalCellsAndUpdateWinner() ||
                   CheckWinOnVerticalCellsAndUpdateWinner() ||
                   CheckWinOnDiagonalCellsAndUpdateWinner();
        }

        private bool CheckWinOnHorizontalCellsAndUpdateWinner()
        {
            for (int row = 0; row < 3; row++)
            {
                int sumX = 0, sumO = 0;
                for (int col = 0; col < 3; col++)
                {
                    if (gameField[row][col] == X_MARK) sumX++;
                    if (gameField[row][col] == O_MARK) sumO++;
                }
                if (sumX == 3) { Winner = Mode == GameMode.PlayerVsPlayer ? PLAYER_HUMAN_TITLE + " 1" : PLAYER_HUMAN_TITLE; player1Score++; return true; }
                if (sumO == 3) { Winner = Mode == GameMode.PlayerVsPlayer ? PLAYER_HUMAN_TITLE + " 2" : PLAYER_CPU_TITLE; player2Score++; return true; }
            }
            return false;
        }

        private bool CheckWinOnVerticalCellsAndUpdateWinner()
        {
            for (int col = 0; col < 3; col++)
            {
                int sumX = 0, sumO = 0;
                for (int row = 0; row < 3; row++)
                {
                    if (gameField[row][col] == X_MARK) sumX++;
                    if (gameField[row][col] == O_MARK) sumO++;
                }
                if (sumX == 3) { Winner = Mode == GameMode.PlayerVsPlayer ? PLAYER_HUMAN_TITLE + " 1" : PLAYER_HUMAN_TITLE; player1Score++; return true; }
                if (sumO == 3) { Winner = Mode == GameMode.PlayerVsPlayer ? PLAYER_HUMAN_TITLE + " 2" : PLAYER_CPU_TITLE; player2Score++; return true; }
            }
            return false;
        }

        private bool CheckWinOnDiagonalCellsAndUpdateWinner()
        {
            int d1X = 0, d2X = 0, d1O = 0, d2O = 0;
            for (int i = 0; i < 3; i++)
            {
                if (gameField[i][i] == X_MARK) d1X++;
                if (gameField[i][2 - i]());
            }
        }
    }
}
