using System;
using System.Drawing;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class FrmTicTacToe : Form
    {
        private GameEngine engine = new GameEngine();
        private Panel[,] cellPanels = new Panel[3, 3];

        public FrmTicTacToe()
        {
            InitializeComponent();
            this.Load += FrmTicTacToe_Load;
        }

        private void FrmTicTacToe_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.MidnightBlue;
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(585, 327);
            this.Text = "TicTacToe";

            CreateGameGrid();
        }

        private void CreateGameGrid()
        {
            int startX = 12, startY = 12, size = 96, margin = 3;
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    Panel panel = new Panel();
                    panel.BackColor = Color.Indigo;
                    panel.Location = new Point(startX + col * (size + margin), startY + row * (size + margin));
                    panel.Size = new Size(size, size);
                    panel.Name = $"panelCell{row}_{col}";
                    panel.MouseEnter += (s, e) => CellMouseOver(s);
                    panel.MouseLeave += (s, e) => CellMouseOut(s);
                    panel.Click += (s, e) => FillCell((Panel)s, row, col);
                    this.Controls.Add(panel);
                    cellPanels[row, col] = panel;
                }
            }
        }

        private void CellMouseOver(object sender)
        {
            if (sender is Panel panel)
            {
                panel.BackColor = Color.Purple;
                Cursor = Cursors.Hand;
            }
        }

        private void CellMouseOut(object sender)
        {
            if (sender is Panel panel)
            {
                panel.BackColor = Color.Indigo;
                Cursor = Cursors.Default;
            }
        }

        private void FillCell(Panel panel, int row, int col)
        {
            if (!engine.IsGameStarted()) return;

            Label markLabel = new Label
            {
                Font = new Font(FontFamily.GenericMonospace, 48, FontStyle.Bold),
                AutoSize = true,
                Text = engine.GetCurrentMarkLabelText(),
                ForeColor = engine.GetCurrentMarkLabelColor(),
                Location = new Point(panel.Width / 2 - 20, panel.Height / 2 - 30)
            };

            panel.Controls.Clear();
            panel.Controls.Add(markLabel);

            engine.MakeTurnAndFillGameFieldCell(row, col);

            if (engine.IsWin())
            {
                MessageBox.Show("Победил " + engine.GetWinner());
                engine.PrepareForNewGame();
                ClearGameField();
                return;
            }

            if (engine.IsDraw())
            {
                MessageBox.Show("Ничья!");
                engine.PrepareForNewGame();
                ClearGameField();
                return;
            }

            if (engine.GetCurrentTurn() == GameEngine.WhooseTurn.Player2CPU)
            {
                var cell = engine.MakeComputerTurnAndGetCell();
                if (!cell.IsErrorCell())
                {
                    FillCell(cellPanels[cell.Row, cell.Column], cell.Row, cell.Column);
                }
            }
        }

        private void ClearGameField()
        {
            engine.ClearGameField();
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    cellPanels[row, col].Controls.Clear();
                }
            }
            engine.SetPlayer1HumanTurn();
        }
    }
}
