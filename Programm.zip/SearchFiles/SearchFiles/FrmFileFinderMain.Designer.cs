﻿namespace FileFinderExample
{
    partial class FrmFileFinderMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ComboBoxDrives = new System.Windows.Forms.ComboBox();
            this.TextBoxSearchPath = new System.Windows.Forms.TextBox();
            this.ButtonSelectSearchDirectory = new System.Windows.Forms.Button();
            this.LabelDrive = new System.Windows.Forms.Label();
            this.ListViewFoundFiles = new System.Windows.Forms.ListView();
            this.ProgressBarMain = new System.Windows.Forms.ProgressBar();
            this.BackgroundWorkerEstimateSearchTime = new System.ComponentModel.BackgroundWorker();
            this.BackgroundWorkerSearchFiles = new System.ComponentModel.BackgroundWorker();
            this.FolderBrowserDialogSelectSearchDirectory = new System.Windows.Forms.FolderBrowserDialog();
            this.ToolTipHints = new System.Windows.Forms.ToolTip(this.components);
            this.LabelSearchPath = new System.Windows.Forms.Label();
            this.LabelFileName = new System.Windows.Forms.Label();
            this.LabelFoundFilesList = new System.Windows.Forms.Label();
            this.LabelProgress = new System.Windows.Forms.Label();
            this.LabelFilesCount = new System.Windows.Forms.Label();
            this.TextBoxFileName = new System.Windows.Forms.TextBox();
            this.ButtonStartSearch = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ComboBoxDrives
            // 
            this.ComboBoxDrives.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxDrives.FormattingEnabled = true;
            this.ComboBoxDrives.Location = new System.Drawing.Point(126, 6);
            this.ComboBoxDrives.Name = "ComboBoxDrives";
            this.ComboBoxDrives.Size = new System.Drawing.Size(662, 21);
            this.ComboBoxDrives.TabIndex = 0;
            // 
            // TextBoxSearchPath
            // 
            this.TextBoxSearchPath.Location = new System.Drawing.Point(15, 57);
            this.TextBoxSearchPath.Name = "TextBoxSearchPath";
            this.TextBoxSearchPath.ReadOnly = true;
            this.TextBoxSearchPath.Size = new System.Drawing.Size(632, 20);
            this.TextBoxSearchPath.TabIndex = 1;
            // 
            // ButtonSelectSearchDirectory
            // 
            this.ButtonSelectSearchDirectory.Location = new System.Drawing.Point(653, 55);
            this.ButtonSelectSearchDirectory.Name = "ButtonSelectSearchDirectory";
            this.ButtonSelectSearchDirectory.Size = new System.Drawing.Size(135, 23);
            this.ButtonSelectSearchDirectory.TabIndex = 2;
            this.ButtonSelectSearchDirectory.Text = "&Обзор";
            this.ButtonSelectSearchDirectory.UseVisualStyleBackColor = true;
            // 
            // LabelDrive
            // 
            this.LabelDrive.AutoSize = true;
            this.LabelDrive.Location = new System.Drawing.Point(14, 9);
            this.LabelDrive.Name = "LabelDrive";
            this.LabelDrive.Size = new System.Drawing.Size(97, 13);
            this.LabelDrive.TabIndex = 3;
            this.LabelDrive.Text = "Диск для поиска:";
            // 
            // ListViewFoundFiles
            // 
            this.ListViewFoundFiles.FullRowSelect = true;
            this.ListViewFoundFiles.GridLines = true;
            this.ListViewFoundFiles.HideSelection = false;
            this.ListViewFoundFiles.Location = new System.Drawing.Point(15, 172);
            this.ListViewFoundFiles.MultiSelect = false;
            this.ListViewFoundFiles.Name = "ListViewFoundFiles";
            this.ListViewFoundFiles.Size = new System.Drawing.Size(773, 270);
            this.ListViewFoundFiles.TabIndex = 4;
            this.ListViewFoundFiles.UseCompatibleStateImageBehavior = false;
            this.ListViewFoundFiles.View = System.Windows.Forms.View.Details;
            // 
            // ProgressBarMain
            // 
            this.ProgressBarMain.Location = new System.Drawing.Point(15, 470);
            this.ProgressBarMain.MarqueeAnimationSpeed = 30;
            this.ProgressBarMain.Name = "ProgressBarMain";
            this.ProgressBarMain.Size = new System.Drawing.Size(773, 23);
            this.ProgressBarMain.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.ProgressBarMain.TabIndex = 5;
            // 
            // BackgroundWorkerEstimateSearchTime
            // 
            this.BackgroundWorkerEstimateSearchTime.WorkerReportsProgress = true;
            this.BackgroundWorkerEstimateSearchTime.WorkerSupportsCancellation = true;
            // 
            // BackgroundWorkerSearchFiles
            // 
            this.BackgroundWorkerSearchFiles.WorkerReportsProgress = true;
            this.BackgroundWorkerSearchFiles.WorkerSupportsCancellation = true;
            // 
            // ToolTipHints
            // 
            this.ToolTipHints.AutoPopDelay = 20000;
            this.ToolTipHints.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ToolTipHints.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ToolTipHints.InitialDelay = 100;
            this.ToolTipHints.ReshowDelay = 1000;
            this.ToolTipHints.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.ToolTipHints.ToolTipTitle = "Подсказка";
            // 
            // LabelSearchPath
            // 
            this.LabelSearchPath.AutoSize = true;
            this.LabelSearchPath.Location = new System.Drawing.Point(14, 41);
            this.LabelSearchPath.Name = "LabelSearchPath";
            this.LabelSearchPath.Size = new System.Drawing.Size(94, 13);
            this.LabelSearchPath.TabIndex = 6;
            this.LabelSearchPath.Text = "Путь для поиска:";
            // 
            // LabelFileName
            // 
            this.LabelFileName.AutoSize = true;
            this.LabelFileName.Location = new System.Drawing.Point(14, 91);
            this.LabelFileName.Name = "LabelFileName";
            this.LabelFileName.Size = new System.Drawing.Size(395, 13);
            this.LabelFileName.TabIndex = 7;
            this.LabelFileName.Text = "Полное имя файла, часть имени файла или часть пути, содержащего файл :";
            // 
            // LabelFoundFilesList
            // 
            this.LabelFoundFilesList.AutoSize = true;
            this.LabelFoundFilesList.Location = new System.Drawing.Point(14, 146);
            this.LabelFoundFilesList.Name = "LabelFoundFilesList";
            this.LabelFoundFilesList.Size = new System.Drawing.Size(149, 13);
            this.LabelFoundFilesList.TabIndex = 8;
            this.LabelFoundFilesList.Text = "Список найденных файлов :";
            // 
            // LabelProgress
            // 
            this.LabelProgress.AutoSize = true;
            this.LabelProgress.Location = new System.Drawing.Point(14, 454);
            this.LabelProgress.Name = "LabelProgress";
            this.LabelProgress.Size = new System.Drawing.Size(59, 13);
            this.LabelProgress.TabIndex = 9;
            this.LabelProgress.Text = "Прогресс:";
            // 
            // LabelFilesCount
            // 
            this.LabelFilesCount.AutoSize = true;
            this.LabelFilesCount.Location = new System.Drawing.Point(774, 454);
            this.LabelFilesCount.Name = "LabelFilesCount";
            this.LabelFilesCount.Size = new System.Drawing.Size(13, 13);
            this.LabelFilesCount.TabIndex = 10;
            this.LabelFilesCount.Text = "0";
            // 
            // TextBoxFileName
            // 
            this.TextBoxFileName.Location = new System.Drawing.Point(15, 107);
            this.TextBoxFileName.Name = "TextBoxFileName";
            this.TextBoxFileName.Size = new System.Drawing.Size(632, 20);
            this.TextBoxFileName.TabIndex = 11;
            // 
            // ButtonStartSearch
            // 
            this.ButtonStartSearch.Location = new System.Drawing.Point(653, 105);
            this.ButtonStartSearch.Name = "ButtonStartSearch";
            this.ButtonStartSearch.Size = new System.Drawing.Size(135, 23);
            this.ButtonStartSearch.TabIndex = 12;
            this.ButtonStartSearch.Text = "&Начать поиск";
            this.ButtonStartSearch.UseVisualStyleBackColor = true;
            // 
            // FrmFileFinderMain
            // 
            this.AcceptButton = this.ButtonSelectSearchDirectory;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 523);
            this.Controls.Add(this.ButtonStartSearch);
            this.Controls.Add(this.TextBoxFileName);
            this.Controls.Add(this.LabelFilesCount);
            this.Controls.Add(this.LabelProgress);
            this.Controls.Add(this.LabelFoundFilesList);
            this.Controls.Add(this.LabelFileName);
            this.Controls.Add(this.LabelSearchPath);
            this.Controls.Add(this.ProgressBarMain);
            this.Controls.Add(this.ListViewFoundFiles);
            this.Controls.Add(this.LabelDrive);
            this.Controls.Add(this.ButtonSelectSearchDirectory);
            this.Controls.Add(this.TextBoxSearchPath);
            this.Controls.Add(this.ComboBoxDrives);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmFileFinderMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "[Allineed.Ru] Пример поиска файлов в системе с помощью элементов BackgroundWorker" +
    "";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ComboBoxDrives;
        private System.Windows.Forms.TextBox TextBoxSearchPath;
        private System.Windows.Forms.Button ButtonSelectSearchDirectory;
        private System.Windows.Forms.Label LabelDrive;
        private System.Windows.Forms.ListView ListViewFoundFiles;
        private System.Windows.Forms.ProgressBar ProgressBarMain;
        private System.ComponentModel.BackgroundWorker BackgroundWorkerEstimateSearchTime;
        private System.ComponentModel.BackgroundWorker BackgroundWorkerSearchFiles;
        private System.Windows.Forms.FolderBrowserDialog FolderBrowserDialogSelectSearchDirectory;
        private System.Windows.Forms.ToolTip ToolTipHints;
        private System.Windows.Forms.Label LabelSearchPath;
        private System.Windows.Forms.Label LabelFileName;
        private System.Windows.Forms.Label LabelFoundFilesList;
        private System.Windows.Forms.Label LabelProgress;
        private System.Windows.Forms.Label LabelFilesCount;
        private System.Windows.Forms.TextBox TextBoxFileName;
        private System.Windows.Forms.Button ButtonStartSearch;
    }
}

