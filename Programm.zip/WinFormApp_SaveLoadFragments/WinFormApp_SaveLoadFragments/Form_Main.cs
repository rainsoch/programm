﻿using System;
using System.Drawing;
using System.Windows.Forms;
using WinFormApp_SaveLoadFragments;
using WinFormApp_SaveLoadFragments.Properties;


namespace WindowsFormsApp1
{
    public partial class form_Main : Form
    {
        private ArrayPictures _arr_pictures;
        private int? firstClickIndex = null;

        public form_Main()
        {
            InitializeComponent();

            int ind_image = 0;
            Image im_pic = (Image)Resources.ResourceManager.GetObject("Task_" + (ind_image + 1).ToString());
            Bitmap bmp_pic = new Bitmap(im_pic);
            Size size_pic = new Size(pictureBox.Width, pictureBox.Height);
            _arr_pictures = new ArrayPictures(pictureBox, bmp_pic, size_pic, 3, 4);
            AssignPictures();

            this.SizeChanged += Form_Main_SizeChanged;

            button_Close.Click += (s, e) => this.Close();
        }

        private void Form_Main_SizeChanged(object sender, EventArgs e)
        {
            Size pic_size = new Size(this.Size.Width - 20, this.Size.Height - 100);
            pictureBox.Size = pic_size;
            _arr_pictures.Set_Sizes(pic_size);

            int margin = 10;
            int controlWidth = (this.Width - 4 * margin) / 3;
            int controlTop = pictureBox.Bottom + margin;

            radioButton_Load.SetBounds(margin, controlTop, controlWidth, 30);
            radioButton_SaveAs.SetBounds(2 * margin + controlWidth, controlTop, controlWidth, 30);
            button_Close.SetBounds(3 * margin + 2 * controlWidth, controlTop, controlWidth, 30);
        }

        private void AssignPictures()
        {
            foreach (PictureBox pic in _arr_pictures.Get_Pictures())
            {
                int index = (int)pic.Tag;
                pic.Click += new EventHandler(fragment_Click);
                pic.Visible = true;
            }
        }

        private void fragment_Click(object sender, EventArgs e)
        {
            PictureBox pic = (PictureBox)sender;
            int index = (int)pic.Tag;

            if (radioButton_Load.Checked)
            {
                Load_Fragment(index);
            }
            else if (radioButton_SaveAs.Checked)
            {
                Save_Fragment(index);
            }
            else
            {
                if (firstClickIndex == null)
                {
                    firstClickIndex = index;
                }
                else
                {
                    _arr_pictures.Swap_Bmp(firstClickIndex.Value, index);
                    firstClickIndex = null;
                }
            }
        }

        private void Load_Fragment(int index)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "файлы картинок (*.bmp;*.jpg;*.jpeg;)|*.bmp;*.jpg;*.jpeg|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Bitmap pic_show = new Bitmap(openFileDialog.FileName);
                _arr_pictures.Change_Bmp(index, pic_show);
            }
        }

        private void Save_Fragment(int index)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "файлы картинок (*.bmp;*.jpg;*.jpeg;)|*.bmp;*.jpg;*.jpeg|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 1;
            saveFileDialog.RestoreDirectory = true;
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string str_file = saveFileDialog.FileName;
                PictureBox pic = _arr_pictures[index];
                pic.Image.Save(str_file);
            }
        }
    }
}
