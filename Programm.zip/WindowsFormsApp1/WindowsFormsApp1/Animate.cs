﻿using System;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AnimationExample
{
    public partial class Animate : Form
    {
        int d = 1;

        public Animate()
        {
            InitializeComponent();
            pictureBox1.Image = Image.FromFile("Ris2.jpg"); // начальное изображение
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Left = pictureBox1.Left + d;

            if (pictureBox1.Left >= this.ClientSize.Width - pictureBox1.Width || pictureBox1.Left <= 0)
            {
                if (d > 0)
                    pictureBox1.Image = Image.FromFile("Ris1.jpg");
                else
                    pictureBox1.Image = Image.FromFile("Ris2.jpg");

                d = -d;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (d >= 0)
                d = trackBar1.Value;
            else
                d = -trackBar1.Value;
        }
    }
}
